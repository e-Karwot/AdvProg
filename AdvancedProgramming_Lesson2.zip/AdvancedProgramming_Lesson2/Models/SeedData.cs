﻿using AdvancedProgramming_Lesson2.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace AdvancedProgramming_Lesson2.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using var context = new MvcContext(
                serviceProvider.GetRequiredService<DbContextOptions<MvcContext>>());
            // Look for any movies.
            if (context.Movie.Any())
            {
                return; // DB has been seeded
            }
            context.Movie.AddRange(
            new Movie
            {
                Title = "Hunger Games",
                ReleaseDate = DateTime.Parse("2012-3-12"),
                Genre = "Action",
                Price = 7.99M,
                Director = "Gary Ross",
                Screenwriter = "Gary Ross"
            },
            new Movie
            {
                Title = "Ghostbusters",
                ReleaseDate = DateTime.Parse("1984-6-7"),
                Genre = "Comedy",
                Price = 8.99M,
                Director = "Ivan Reitman",
                Screenwriter = "Rick Moranis"
            },
            new Movie
            {
                Title = "Matrix",
                ReleaseDate = DateTime.Parse("1999-3-24"),
                Genre = "Action/Sci-Fi",
                Price = 9.99M,
                Director = "Lilly Wachowski, Lana Wachowski",
                Screenwriter = "Lilly Wachowski, Lana Wachowski"
            },
            new Movie
            {
                Title = "The Godfather",
                ReleaseDate = DateTime.Parse("1972-3-15"),
                Genre = "Drama",
                Price = 3.99M,
                Director = "Francis Ford Coppola",
                Screenwriter = "Mario Puzo"
            }
            );
            context.SaveChanges();
        }
    }
}
