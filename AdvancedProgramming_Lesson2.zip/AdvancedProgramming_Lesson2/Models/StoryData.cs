﻿using AdvancedProgramming_Lesson2.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace AdvancedProgramming_Lesson2.Models
{
    public static class StoryData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using var context = new MvcStoryContext(
                serviceProvider.GetRequiredService<DbContextOptions<MvcStoryContext>>());
            // Look for any stories.
            if (context.Story.Any())
            {
                return; // DB has been seeded
            }
            context.Story.AddRange(
            new Story
            {
                Title = "Kolor z Przestworzy",
                ReleaseDate = DateTime.Parse("1989-2-12"),
                Genre = "Horror",
                Price = 36.50M
            },
            new Story
            {
                Title = "Coś na Progu",
                ReleaseDate = DateTime.Parse("1986-5-1"),
                Genre = "Horror",
                Price = 29.99M
            },
            new Story
            {
                Title = "Alicja w Krainie Czarów",
                ReleaseDate = DateTime.Parse("1989-2-12"),
                Genre = "Fantasy",
                Price = 19.0M
            },
            new Story
            {
                Title = "Diuna",
                ReleaseDate = DateTime.Parse("1994-10-16"),
                Genre = "Sci-Fi",
                Price = 40.0M
            }
            );
            context.SaveChanges();
        }
    }
}
