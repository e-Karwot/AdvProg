﻿using AdvancedProgramming_Lesson2.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace AdvancedProgramming_Lesson2.Models
{
    public static class GameData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using var context = new MvcGameContext(
                serviceProvider.GetRequiredService<DbContextOptions<MvcGameContext>>());
            // Look for any games.
            if (context.Game.Any())
            {
                return; // DB has been seeded
            }
            context.Game.AddRange(
            new Game
            {
                Title = "Eldritch Horror",
                ReleaseDate = DateTime.Parse("2001-10-12"),
                Genre = "Kooperacja",
                Publisher = "Galakta"
            },
            new Game
            {
                Title = "Osadnicy z Catanu",
                ReleaseDate = DateTime.Parse("1995-7-1"),
                Genre = "Ekonomiczna",
                Publisher = "Kosmos"
            },
            new Game
            {
                Title = "Gra o Tron",
                ReleaseDate = DateTime.Parse("2016-11-25"),
                Genre = "Area control",
                Publisher = "Galakta"
            },
            new Game
            {
                Title = "War Chest",
                ReleaseDate = DateTime.Parse("2001-2-10"),
                Genre = "Abstrakcyjna/Bitewna",
                Publisher = "AEG"
            }
            );
            context.SaveChanges();
        }
    }
}
