﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson2.Models
{
    public class Game
    {
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Required(ErrorMessage = "This field cannot be empty!")]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Please add the release date of the game.")]
        [DataType(DataType.Date)]
        [Display(Name = "Release date")]
        public DateTime ReleaseDate { get; set; }

        [Required(ErrorMessage = "This field cannot be empty!")]
        [StringLength(30)]
        [Display(Name = "Genre")]
        public string Genre { get; set; }

        [Required(ErrorMessage = "This field cannot be empty!")]
        [StringLength(30)]
        [Display(Name = "Publisher")]
        public string Publisher { get; set; }
    }
}
