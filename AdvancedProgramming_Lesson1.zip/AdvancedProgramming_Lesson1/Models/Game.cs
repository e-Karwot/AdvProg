﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Game
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Tytuł")]
        public string Title { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data premiery")]
        public DateTime ReleaseDate { get; set; }

        [Required]
        [StringLength(30)]
        [Display(Name = "Rodzaj")]
        public string Genre { get; set; }

        [Required]
        [StringLength(30)]
        [Display(Name = "Wydawca")]
        public string Publisher { get; set; }
    }
}
