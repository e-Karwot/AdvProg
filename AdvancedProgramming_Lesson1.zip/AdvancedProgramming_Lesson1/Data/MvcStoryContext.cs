﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcStoryContext : DbContext
    {
        public MvcStoryContext(DbContextOptions<MvcStoryContext> options)
        : base(options)
        {
        }
        public DbSet<Story> Story { get; set; }
    }
}
