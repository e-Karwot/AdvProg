﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdvancedProgramming_Lesson1.Data;
using AdvancedProgramming_Lesson1.Models;

namespace AdvancedProgramming_Lesson1
{
    public class StorysController : Controller
    {
        private readonly MvcStoryContext _context;

        public StorysController(MvcStoryContext context)
        {
            _context = context;
        }

        // GET: Storys
        public async Task<IActionResult> Index()
        {
            return View(await _context.Story.ToListAsync());
        }

        // GET: Storys/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Story = await _context.Story
                .FirstOrDefaultAsync(m => m.Id == id);
            if (Story == null)
            {
                return NotFound();
            }

            return View(Story);
        }

        // GET: Storys/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Storys/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,ReleaseDate,Genre,Price")] Story Story)
        {
            if (ModelState.IsValid)
            {
                _context.Add(Story);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(Story);
        }

        // GET: Storys/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Story = await _context.Story.FindAsync(id);
            if (Story == null)
            {
                return NotFound();
            }
            return View(Story);
        }

        // POST: Storys/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,ReleaseDate,Genre,Price")] Story Story)
        {
            if (id != Story.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(Story);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StoryExists(Story.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(Story);
        }

        // GET: Storys/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Story = await _context.Story
                .FirstOrDefaultAsync(m => m.Id == id);
            if (Story == null)
            {
                return NotFound();
            }

            return View(Story);
        }

        // POST: Storys/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var Story = await _context.Story.FindAsync(id);
            _context.Story.Remove(Story);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StoryExists(int id)
        {
            return _context.Story.Any(e => e.Id == id);
        }
    }
}
